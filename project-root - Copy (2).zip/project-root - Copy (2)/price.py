import re
import csv

# Load the entire HTML file as raw text
def load_html_file_raw(file_path):
    with open(file_path, 'r', encoding='utf-8') as file:
        return file.read()

# Extract price-like patterns from raw HTML content
def extract_prices_from_raw(html_raw_text):
    # Regex to catch prices like $15, $1,299.99, etc.
    price_pattern = r'\$\s?\d{1,3}(?:,\d{3})*(?:\.\d{2})?'

    # Find all matches
    matches = re.findall(price_pattern, html_raw_text)
    return list(set(matches))  # Remove duplicates

# Save results to CSV
def save_to_csv(prices, output_file='extracted_prices.csv'):
    with open(output_file, 'w', newline='', encoding='utf-8') as file:
        writer = csv.writer(file)
        writer.writerow(['Price'])
        for price in prices:
            writer.writerow([price])
    print(f"[✔] Extracted {len(prices)} prices to '{output_file}'")

# Main function
def main():
    html_file = 'pages\page_0_20250509_221658.html'  # Update with your actual file
    raw_html = load_html_file_raw(html_file)
    prices = extract_prices_from_raw(raw_html)
    if prices:
        save_to_csv(prices)
    else:
        print("[!] No prices found in the file.")

if __name__ == "__main__":
    main()
