from flask import Flask, render_template, request, jsonify
import json
import os
from datetime import datetime
import pandas as pd

app = Flask(__name__)

# Ensure the search_container.json file exists
def ensure_json_file():
    if not os.path.exists('search_container.json'):
        with open('search_container.json', 'w') as f:
            json.dump({
                "search_query": "",
                "timestamp": "",
                "status": "pending",
                "version": 1
            }, f, indent=4)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/save_search', methods=['POST'])
def save_search():
    try:
        data = request.get_json()
        if not data or 'search_query' not in data:
            return jsonify({'success': False, 'error': 'Search query is required'}), 400

        # Ensure the JSON file exists
        ensure_json_file()

        # Create the search data
        search_data = {
            "search_query": data['search_query'],
            "timestamp": data.get('timestamp', datetime.now().strftime('%Y-%m-%d %H:%M:%S')),
            "status": data.get('status', 'pending'),
            "version": data.get('version', 1)
        }

        # Update the search_container.json with new data
        try:
            with open('search_container.json', 'w') as f:
                json.dump(search_data, f, indent=4)
        except Exception as e:
            return jsonify({'success': False, 'error': f'Failed to write to file: {str(e)}'}), 500

        return jsonify({'success': True, 'message': 'Search query saved successfully'})

    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/search', methods=['POST'])
def search():
    try:
        data = request.get_json()
        if not data or 'search_query' not in data:
            return jsonify({'success': False, 'error': 'Search query is required'}), 400

        search_query = data['search_query']
        
        # Process the search query here
        # This is where you would implement your search logic
        
        return jsonify({
            'success': True,
            'message': 'Search query processed successfully'
        })

    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/search_history')
def search_history():
    try:
        ensure_json_file()
        with open('search_container.json', 'r') as f:
            searches = json.load(f)
        return jsonify(searches)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/tickets')
def get_ticket_data():
    try:
        # Read the CSV file
        df = pd.read_csv('best_deals_20250510_001013.csv')
        
        # Calculate statistics
        total_events = len(df)
        average_price = round(df['Price'].mean(), 2)
        min_price = round(df['Price'].min(), 2)
        max_price = round(df['Price'].max(), 2)
        
        # Get recent events (last 10)
        recent_events = df.tail(10).apply(lambda row: {
            'event_name': row['Event Name'],
            'venue': row['Venue'],
            'price': round(float(row['Price']), 2),
            'platform': row['Platform'],
            'date_time': row['Date & Time'],
            'event_url': row['Event URL'],
            'description': row.get('Description', 'No description available'),
            'start_time': row.get('Start Time', 'Not specified'),
            'end_time': row.get('End Time', 'Not specified'),
            'location': row.get('Location', row['Venue'])
        }, axis=1).tolist()
        
        return jsonify({
            'total_events': total_events,
            'average_price': average_price,
            'min_price': min_price,
            'max_price': max_price,
            'events': recent_events
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True, port=5500) 