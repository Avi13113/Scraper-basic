from bs4 import BeautifulSoup
import csv

def extract_links(html_file):
    # Read the HTML file
    with open(html_file, 'r', encoding='utf-8') as file:
        content = file.read()
    
    # Create BeautifulSoup object
    soup = BeautifulSoup(content, 'html.parser')
    
    # Find all links with the specified class
    target_links = []
    
    # Find links with the specified button class
    button_links = soup.find_all('a', class_='indexstyles__StyledButton-sc-83qv1q-0 eSghXc sc-88d1592a-4 jzDXiR')
    
    # Find links with event-list-link data attribute
    event_list_links = soup.find_all('a', attrs={'data-testid': 'event-list-link'})
    
    # Combine and deduplicate links
    all_links = set()
    
    for link in button_links + event_list_links:
        href = link.get('href')
        if href:
            all_links.add(href)
    
    # Save links to CSV file
    with open('extracted_links.csv', 'w', newline='', encoding='utf-8') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(['Link'])  # Header
        for link in all_links:
            writer.writerow([link])

if __name__ == "__main__":
    html_file = "outputs/ticketmaster_Forgotten_Club_Bangers_20250509_213201.html"
    extract_links(html_file)
    print("Links have been extracted and saved to extracted_links.csv") 