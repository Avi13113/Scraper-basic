import pandas as pd
import logging
from datetime import datetime
import os

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(f'ticket_analysis_{datetime.now().strftime("%Y%m%d_%H%M%S")}.log'),
        logging.StreamHandler()
    ]
)

class TicketAnalyzer:
    def __init__(self):
        self.best_deals = []

    def clean_price(self, price_str):
        """Clean and convert price string to float"""
        try:
            # Remove currency symbols and commas
            price_str = str(price_str).replace('$', '').replace(',', '').strip()
            return float(price_str)
        except (ValueError, TypeError):
            return float('inf')  # Return infinity for invalid prices

    def analyze_tickets(self, csv_file):
        """Analyze tickets and find the best deals"""
        try:
            # Read the CSV file
            logging.info(f"Reading CSV file: {csv_file}")
            df = pd.read_csv(csv_file)

            # Required columns check
            required_columns = ['event_name', 'date_time', 'venue', 'price', 'platform', 'event_url']
            missing_columns = [col for col in required_columns if col not in df.columns]
            if missing_columns:
                logging.error(f"Missing required columns: {missing_columns}")
                return False

            # Clean and convert prices
            df['price'] = df['price'].apply(self.clean_price)

            # Group by event name
            best_deals = []
            for event in df['event_name'].unique():
                event_df = df[df['event_name'] == event]
                best_deal = event_df.loc[event_df['price'].idxmin()]
                
                deal_info = {
                    'Event Name': best_deal['event_name'],
                    'Date & Time': best_deal['date_time'],
                    'Venue': best_deal['venue'],
                    'Price': best_deal['price'],
                    'Platform': best_deal['platform'],
                    'Event URL': best_deal['event_url'],
                    'Description': best_deal.get('description', 'N/A'),
                    'Start Time': best_deal.get('start_time', 'N/A'),
                    'End Time': best_deal.get('end_time', 'N/A'),
                    'Location': f"{best_deal.get('latitude', 'N/A')}, {best_deal.get('longitude', 'N/A')}"
                }
                best_deals.append(deal_info)

            self.best_deals = best_deals
            return True

        except Exception as e:
            logging.error(f"Error analyzing tickets: {str(e)}")
            return False

    def save_best_deals(self, output_file):
        """Save the best deals to a CSV file"""
        try:
            if not self.best_deals:
                logging.error("No deals to save")
                return False

            # Create DataFrame from best deals
            df = pd.DataFrame(self.best_deals)
            
            # Sort by price
            df = df.sort_values('Price')
            
            # Save to CSV
            df.to_csv(output_file, index=False)
            logging.info(f"Best deals saved to: {output_file}")
            
            # Print summary
            print("\nBest Deals Found:")
            print("=" * 100)
            for _, deal in df.iterrows():
                print(f"Event Name: {deal['Event Name']}")
                print(f"Date & Time: {deal['Date & Time']}")
                print(f"Venue: {deal['Venue']}")
                print(f"Price: ${deal['Price']:.2f}")
                print(f"Platform: {deal['Platform']}")
                print(f"Event URL: {deal['Event URL']}")
                print(f"Description: {deal['Description']}")
                print(f"Start Time: {deal['Start Time']}")
                print(f"End Time: {deal['End Time']}")
                print(f"Location: {deal['Location']}")
                print("-" * 100)
            
            return True

        except Exception as e:
            logging.error(f"Error saving best deals: {str(e)}")
            return False

def main():
    # Use the specific CSV file path
    input_file = "Extracted_Event_details.csv"
    
    # Validate input file
    if not os.path.exists(input_file):
        print(f"Error: File '{input_file}' not found!")
        return

    # Create output filename
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_file = f"best_deals_{timestamp}.csv"

    # Initialize analyzer and process tickets
    analyzer = TicketAnalyzer()
    if analyzer.analyze_tickets(input_file):
        analyzer.save_best_deals(output_file)
    else:
        print("Error analyzing tickets. Check the log file for details.")

if __name__ == "__main__":
    main() 