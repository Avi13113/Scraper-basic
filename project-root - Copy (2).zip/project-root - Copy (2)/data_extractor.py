import re
import csv
from bs4 import BeautifulSoup

# Load the entire HTML file as raw text
def load_html_file_raw(file_path):
    with open(file_path, 'r', encoding='utf-8') as file:
        return file.read()

# Extract price-like patterns from raw HTML content
def extract_prices_from_raw(html_raw_text):
    # Regex to catch prices like $15, $1,299.99, etc.
    price_pattern = r'\$\s?\d{1,3}(?:,\d{3})*(?:\.\d{2})?'

    # Find all matches
    matches = re.findall(price_pattern, html_raw_text)
    return list(set(matches))  # Remove duplicates

def extract_event_details(html_file):
    # Read the HTML file
    with open(html_file, 'r', encoding='utf-8') as file:
        html_content = file.read()

    # Parse HTML
    soup = BeautifulSoup(html_content, 'html.parser')

    # Initialize event details dictionary
    event_details = {}

    # Extract event name from title
    title_tag = soup.find('title')
    if title_tag:
        event_details['event_name'] = title_tag.text.strip().split('|')[0].strip()

    # Extract date and time from meta tags
    date_meta = soup.find('meta', {'name': 'twitter:data2'})
    if date_meta:
        event_details['date_time'] = date_meta.get('value', '')

    # Extract venue from meta tags
    venue_meta = soup.find('meta', {'name': 'twitter:data1'})
    if venue_meta:
        event_details['venue'] = venue_meta.get('value', '')

    # Extract platform name
    platform_meta = soup.find('meta', {'property': 'og:site_name'})
    if platform_meta:
        event_details['platform'] = platform_meta.get('content', '')

    # Extract event description
    desc_meta = soup.find('meta', {'property': 'og:description'})
    if desc_meta:
        event_details['description'] = desc_meta.get('content', '')

    # Extract event URL
    url_meta = soup.find('meta', {'property': 'og:url'})
    if url_meta:
        event_details['event_url'] = url_meta.get('content', '')

    # Extract coordinates
    lat_meta = soup.find('meta', {'property': 'event:location:latitude'})
    long_meta = soup.find('meta', {'property': 'event:location:longitude'})
    if lat_meta and long_meta:
        event_details['latitude'] = lat_meta.get('content', '')
        event_details['longitude'] = long_meta.get('content', '')

    # Extract start and end times
    start_time = soup.find('meta', {'property': 'event:start_time'})
    end_time = soup.find('meta', {'property': 'event:end_time'})
    if start_time and end_time:
        event_details['start_time'] = start_time.get('content', '')
        event_details['end_time'] = end_time.get('content', '')

    return event_details

def save_to_csv(event_details, output_file='event_details.csv'):
    # Define the fieldnames (columns) for the CSV
    fieldnames = [
        'event_name', 'date_time', 'venue', 'platform', 'description',
        'event_url', 'latitude', 'longitude', 'start_time', 'end_time'
    ]
    
    # Check if file exists to determine if we need to write headers
    file_exists = False
    try:
        with open(output_file, 'r', encoding='utf-8') as f:
            file_exists = True
    except FileNotFoundError:
        pass

    # Write to CSV file
    with open(output_file, 'a', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        
        # Write headers only if file is new
        if not file_exists:
            writer.writeheader()
        
        # Write the event details
        writer.writerow(event_details)

def save_prices_to_csv(prices, output_file='extracted_prices.csv'):
    with open(output_file, 'w', newline='', encoding='utf-8') as file:
        writer = csv.writer(file)
        writer.writerow(['Price'])
        for price in prices:
            writer.writerow([price])
    print(f"[✔] Extracted {len(prices)} prices to '{output_file}'")

def main():
    html_file = 'pages\page_0_20250509_221658.html'  # Update with your actual file
    
    # Load raw HTML content
    raw_html = load_html_file_raw(html_file)
    
    # Extract prices
    prices = extract_prices_from_raw(raw_html)
    if prices:
        save_prices_to_csv(prices)
    else:
        print("[!] No prices found in the file.")

    # Extract event details
    event_details = extract_event_details(html_file)
    
    # Save event details to CSV file
    output_file = 'event_details.csv'
    save_to_csv(event_details, output_file)
    
    # Print the extracted event details
    print("\nExtracted Event Details:")
    print("----------------------")
    for key, value in event_details.items():
        print(f"{key}: {value}")
    print(f"\nData has been saved to {output_file}")

if __name__ == "__main__":
    main()
