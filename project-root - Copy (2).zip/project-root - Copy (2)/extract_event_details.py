from bs4 import BeautifulSoup
import csv
from datetime import datetime
import re

def extract_price_details(soup):
    price_details = {
        'prices': [],
        'currency': 'USD'  # Default currency
    }
    
    # Regular expression patterns for different price formats
    price_patterns = [
        r'\$\s*\d+(?:\.\d{2})?',  # $12 or $12.00
        r'\d+(?:\.\d{2})?\s*\$',  # 12$ or 12.00$
        r'USD\s*\d+(?:\.\d{2})?',  # USD 12 or USD 12.00
        r'\d+(?:\.\d{2})?\s*USD',  # 12 USD or 12.00 USD
        r'price:\s*\$\s*\d+(?:\.\d{2})?',  # price: $12
        r'ticket:\s*\$\s*\d+(?:\.\d{2})?'   # ticket: $12
    ]
    
    # Combine all patterns
    combined_pattern = '|'.join(price_patterns)
    
    # Find all text in the HTML
    text_content = soup.get_text()
    
    # Find all price matches
    price_matches = re.finditer(combined_pattern, text_content, re.IGNORECASE)
    
    # Extract unique prices
    seen_prices = set()
    for match in price_matches:
        price = match.group().strip()
        # Clean up the price string
        price = re.sub(r'[^\d.]', '', price)  # Keep only numbers and decimal point
        if price and price not in seen_prices:
            seen_prices.add(price)
            price_details['prices'].append(float(price))
    
    # Sort prices
    price_details['prices'].sort()
    
    # Calculate price range if we found prices
    if price_details['prices']:
        price_details['min_price'] = min(price_details['prices'])
        price_details['max_price'] = max(price_details['prices'])
        price_details['price_range'] = f"${price_details['min_price']} - ${price_details['max_price']}"
    else:
        price_details['min_price'] = ''
        price_details['max_price'] = ''
        price_details['price_range'] = ''

    return price_details

def extract_ticket_prices(soup):
    # Find all occurrences like $15, $ 15, $15.50, $ 17.5, etc. in all visible text nodes
    price_pattern = re.compile(r'\$\s*\d+(?:\.\d+)?')
    prices = set()
    for text in soup.stripped_strings:
        for match in price_pattern.findall(text):
            prices.add(match.replace(' ', ''))  # Remove any spaces, e.g., "$ 15" -> "$15"
    # Return all prices found, comma-separated, or empty string if none
    return ', '.join(sorted(prices, key=lambda x: float(x.replace('$','')))) if prices else ''

def extract_event_details(html_file):
    # Read the HTML file
    with open(html_file, 'r', encoding='utf-8') as file:
        html_content = file.read()

    # Parse HTML
    soup = BeautifulSoup(html_content, 'html.parser')

    # Initialize event details dictionary
    event_details = {}

    # Extract event name from title
    title_tag = soup.find('title')
    if title_tag:
        event_details['event_name'] = title_tag.text.strip().split('|')[0].strip()

    # Extract date and time from meta tags
    date_meta = soup.find('meta', {'name': 'twitter:data2'})
    if date_meta:
        event_details['date_time'] = date_meta.get('value', '')

    # Extract venue from meta tags
    venue_meta = soup.find('meta', {'name': 'twitter:data1'})
    if venue_meta:
        event_details['venue'] = venue_meta.get('value', '')

    # Extract platform name
    platform_meta = soup.find('meta', {'property': 'og:site_name'})
    if platform_meta:
        event_details['platform'] = platform_meta.get('content', '')

    # Extract event description
    desc_meta = soup.find('meta', {'property': 'og:description'})
    if desc_meta:
        event_details['description'] = desc_meta.get('content', '')

    # Extract event URL
    url_meta = soup.find('meta', {'property': 'og:url'})
    if url_meta:
        event_details['event_url'] = url_meta.get('content', '')

    # Extract coordinates
    lat_meta = soup.find('meta', {'property': 'event:location:latitude'})
    long_meta = soup.find('meta', {'property': 'event:location:longitude'})
    if lat_meta and long_meta:
        event_details['latitude'] = lat_meta.get('content', '')
        event_details['longitude'] = long_meta.get('content', '')

    # Extract start and end times
    start_time = soup.find('meta', {'property': 'event:start_time'})
    end_time = soup.find('meta', {'property': 'event:end_time'})
    if start_time and end_time:
        event_details['start_time'] = start_time.get('content', '')
        event_details['end_time'] = end_time.get('content', '')

    # Extract price details
    price_details = extract_price_details(soup)
    event_details.update({
        'min_price': price_details['min_price'],
        'max_price': price_details['max_price'],
        'price_range': price_details['price_range'],
        'all_prices': ', '.join(map(str, price_details['prices']))
    })

    # Extract all ticket prices (all $<number> found)
    event_details['ticket_price'] = extract_ticket_prices(soup)

    return event_details

def save_to_csv(event_details, output_file):
    # Define the fieldnames (columns) for the CSV
    fieldnames = [
        'event_name', 'date_time', 'venue', 'platform', 'description',
        'event_url', 'latitude', 'longitude', 'start_time', 'end_time',
        'min_price', 'max_price', 'price_range', 'all_prices', 'ticket_price'
    ]
    
    # Check if file exists to determine if we need to write headers
    file_exists = False
    try:
        with open(output_file, 'r', encoding='utf-8') as f:
            file_exists = True
    except FileNotFoundError:
        pass

    # Write to CSV file
    with open(output_file, 'a', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        
        # Write headers only if file is new
        if not file_exists:
            writer.writeheader()
        
        # Write the event details
        writer.writerow(event_details)

def main():
    # Input HTML file
    html_file = 'pages/page_0_20250509_221658.html'
    
    # Extract event details
    event_details = extract_event_details(html_file)
    
    # Save to CSV file
    output_file = 'event_details.csv'
    save_to_csv(event_details, output_file)
    
    # Print the extracted details
    print("\nExtracted Event Details:")
    print("----------------------")
    for key, value in event_details.items():
        print(f"{key}: {value}")
    print(f"\nData has been saved to {output_file}")

if __name__ == "__main__":
    main() 