import pandas as pd
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException
import os
from urllib.parse import urlparse
import time
import json
import logging

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('webpage_downloader.log'),
        logging.StreamHandler()
    ]
)

def setup_driver():
    try:
        # Set up Chrome options
        chrome_options = Options()
        chrome_options.add_argument('--headless=new')  # Updated headless mode
        chrome_options.add_argument('--disable-gpu')
        chrome_options.add_argument('--no-sandbox')
        chrome_options.add_argument('--disable-dev-shm-usage')
        chrome_options.add_argument('--window-size=1920,1080')
        
        # Initialize the Chrome WebDriver
        service = Service()
        driver = webdriver.Chrome(service=service, options=chrome_options)
        logging.info("WebDriver initialized successfully")
        return driver
    except Exception as e:
        logging.error(f"Failed to initialize WebDriver: {str(e)}")
        raise

def download_webpage(driver, url, index):
    try:
        # Navigate to the URL
        logging.info(f"Navigating to URL {index}: {url}")
        driver.get(url)
        
        # Wait for the page to load
        time.sleep(5)
        
        # Get the page source after JavaScript execution
        page_source = driver.page_source
        
        # Create a safe filename
        safe_filename = f"page_{index}.html"
        
        # Create pages directory if it doesn't exist
        os.makedirs('pages', exist_ok=True)
        
        # Save the webpage
        filepath = os.path.join('pages', safe_filename)
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(page_source)
        
        logging.info(f"Successfully downloaded: {url} -> {filepath}")
        return True
    
    except Exception as e:
        logging.error(f"Error downloading {url}: {str(e)}")
        return False

def main():
    # Read the CSV file
    csv_file = "extracted_links.csv"
    
    try:
        # Verify CSV file exists
        if not os.path.exists(csv_file):
            logging.error(f"CSV file not found: {csv_file}")
            return
            
        logging.info(f"Reading CSV file: {csv_file}")
        df = pd.read_csv(csv_file)
        
        # Check if 'Link' column exists
        if 'Link' not in df.columns:
            logging.error("Error: CSV file must contain a 'Link' column")
            return
        
        # Create pages directory
        os.makedirs('pages', exist_ok=True)
        
        # Initialize the WebDriver
        driver = setup_driver()
        
        try:
            # Download each webpage
            total_links = len(df)
            successful_downloads = 0
            
            logging.info(f"Starting download of {total_links} webpages...")
            
            for index, row in df.iterrows():
                url = row['Link']
                if download_webpage(driver, url, index):
                    successful_downloads += 1
                # Add a small delay between requests
                time.sleep(2)
            
            logging.info(f"\nDownload complete!")
            logging.info(f"Successfully downloaded: {successful_downloads}/{total_links} webpages")
            logging.info(f"Files are saved in the 'pages' directory")
            
        finally:
            # Always close the WebDriver
            driver.quit()
            logging.info("WebDriver closed")
        
    except Exception as e:
        logging.error(f"Error in main process: {str(e)}")

if __name__ == "__main__":
    main() 