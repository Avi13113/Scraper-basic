import pandas as pd
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException
import os
import time
import logging
from datetime import datetime

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(f'scraper_{datetime.now().strftime("%Y%m%d_%H%M%S")}.log'),
        logging.StreamHandler()
    ]
)

class CSVScraper:
    def __init__(self):
        self.driver = None
        self.setup_driver()

    def setup_driver(self):
        """Initialize the Chrome WebDriver with appropriate options"""
        try:
            chrome_options = Options()
            # Run in visible mode (not headless) so you can see the browser
            # chrome_options.add_argument('--headless=new')
            chrome_options.add_argument('--disable-gpu')
            chrome_options.add_argument('--no-sandbox')
            chrome_options.add_argument('--disable-dev-shm-usage')
            chrome_options.add_argument('--window-size=1920,1080')
            chrome_options.add_argument('--disable-blink-features=AutomationControlled')
            chrome_options.add_experimental_option("excludeSwitches", ["enable-automation"])
            chrome_options.add_experimental_option('useAutomationExtension', False)
            
            service = Service()
            self.driver = webdriver.Chrome(service=service, options=chrome_options)
            self.driver.execute_cdp_cmd('Network.setUserAgentOverride', {
                "userAgent": 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
            })
            logging.info("WebDriver initialized successfully")
        except Exception as e:
            logging.error(f"Failed to initialize WebDriver: {str(e)}")
            raise

    def download_page(self, url, index):
        """Download a single webpage and save it"""
        try:
            logging.info(f"Navigating to URL {index}: {url}")
            
            # Navigate to the URL
            self.driver.get(url)
            
            # Wait for page to load completely
            time.sleep(5)  # Wait for dynamic content
            
            # Get the complete page source after JavaScript execution
            page_source = self.driver.page_source
            
            # Create a descriptive filename
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"page_{index}_{timestamp}.html"
            
            # Create pages directory if it doesn't exist
            os.makedirs('pages', exist_ok=True)
            filepath = os.path.join('pages', filename)
            
            # Save the webpage
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(page_source)
            
            logging.info(f"Successfully downloaded: {url} -> {filepath}")
            return True
            
        except Exception as e:
            logging.error(f"Error downloading {url}: {str(e)}")
            return False

    def process_csv(self, csv_file):
        """Process the CSV file and download all pages"""
        try:
            # Verify CSV file exists
            if not os.path.exists(csv_file):
                logging.error(f"CSV file not found: {csv_file}")
                return
            
            logging.info(f"Reading CSV file: {csv_file}")
            df = pd.read_csv(csv_file)
            
            # Check if 'Link' column exists
            if 'Link' not in df.columns:
                logging.error("Error: CSV file must contain a 'Link' column")
                return
            
            total_links = len(df)
            successful_downloads = 0
            
            logging.info(f"Starting download of {total_links} webpages...")
            
            for index, row in df.iterrows():
                url = row['Link']
                if self.download_page(url, index):
                    successful_downloads += 1
                time.sleep(2)  # Polite delay between requests
            
            logging.info(f"\nDownload complete!")
            logging.info(f"Successfully downloaded: {successful_downloads}/{total_links} webpages")
            
        except Exception as e:
            logging.error(f"Error processing CSV: {str(e)}")
        finally:
            if self.driver:
                self.driver.quit()
                logging.info("WebDriver closed")

def main():
    # Use the correct path for the CSV file
    csv_file = "extracted_links.csv"
    
    # Initialize and run the scraper
    scraper = CSVScraper()
    scraper.process_csv(csv_file)

if __name__ == "__main__":
    main() 