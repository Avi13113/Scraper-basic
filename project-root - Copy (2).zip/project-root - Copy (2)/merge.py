import csv

def integrate_csv_files(file1, file2, output_file):
    # Read the data from both files
    with open(file1, 'r', encoding='utf-8') as f1, open(file2, 'r', encoding='utf-8') as f2:
        reader1 = csv.reader(f1)
        reader2 = csv.reader(f2)
        
        # Read the header rows
        header1 = next(reader1)
        header2 = next(reader2)

        # Combine headers, adding a suffix to avoid duplicate headers
        combined_header = header1 + header2
        
        # Prepare to store data
        rows1 = list(reader1)
        rows2 = list(reader2)
        
        # Handle different number of rows by padding with empty values
        max_rows = max(len(rows1), len(rows2))
        
        # Pad shorter file with empty columns (None or '')
        while len(rows1) < max_rows:
            rows1.append([''] * len(header1))  # Padding with empty values
        while len(rows2) < max_rows:
            rows2.append([''] * len(header2))  # Padding with empty values

        # Combine data row by row
        combined_rows = []
        for row1, row2 in zip(rows1, rows2):
            combined_row = row1 + row2  # Merge row1 and row2 by columns
            combined_rows.append(combined_row)

    # Write the combined data to the output CSV file
    with open(output_file, 'w', newline='', encoding='utf-8') as output:
        writer = csv.writer(output)
        
        # Write the combined header
        writer.writerow(combined_header)
        
        # Write the combined rows
        writer.writerows(combined_rows)

    print(f"Data successfully integrated into {output_file}")

# Example usage
file1 = 'event_details.csv'  # Update with the path to your first CSV
file2 = 'extracted_prices.csv'  # Update with the path to your second CSV
output_file = 'integrated_file.csv'  # Output file name

integrate_csv_files(file1, file2, output_file)
